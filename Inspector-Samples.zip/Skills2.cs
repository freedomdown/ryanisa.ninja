﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skills2 : MonoBehaviour
{
    public int CurrentMP;//normal variables that will show up in the default inspector
    public int MaxMp = 10;

    [HideInInspector]//hide these ones as we done want them to be drawn by the default inspector
    public List<Buff> BuffArray = new List<Buff>();
    [HideInInspector]
    public List<Attack> AttackArray = new List<Attack>();
    [HideInInspector]
    public List<Summon> SummonArray = new List<Summon>();

    // Use this for initialization
    void Start ()
    {
        CurrentMP = MaxMp;
    }

    public void AddNewSkill(Skill newSkill)//Called by the newSkill window when someone saves the new skill
    {
        if (newSkill.GetType() == typeof(Buff))
            BuffArray.Add((Buff)newSkill);
        else if (newSkill.GetType() == typeof(Attack))
            AttackArray.Add((Attack)newSkill);
        else if (newSkill.GetType() == typeof(Summon))
            SummonArray.Add((Summon)newSkill);
    }
}