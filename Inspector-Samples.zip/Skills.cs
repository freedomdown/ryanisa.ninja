﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skills : MonoBehaviour
{
    public int CurrentMP;
    public int MaxMp = 10;

    public List<Buff> BuffArray = new List<Buff>();
    public List<Attack> AttackArray = new List<Attack>();
    public List<Summon> SummonArray = new List<Summon>();
    //Why not List<Skill> and store all the different skills together?
    //When Unity serializes a component it assume everything is what it was referenced as.
    //It doesn't use reflection or anything such as SkillArray.GetType()
    //So it would forget everything that isn't part of the base class/
    //It will work at runtime, so you can do that temporarily

    // Use this for initialization
    [ContextMenu("test")]
    void Start ()
    {
        CurrentMP = MaxMp;
	}
}




public enum StatEnum    //these enums also get used by the inspector when it creates the dropdown box
{                       //unity uses reflection to get the names of all the values in the enum
    Strength,
    Dexterity,
    Constitution,
    Intelligance,
    Wisdom,
    Charisma
}
public enum DamageEnum
{
    Physical,
    Fire,
    Water,
    Earth,
    Wind,
    Psychic
}

[System.Serializable]//this will make sure unity knows to try and serialize this class when it is saving scenes and prefabs
public class Skill  //base skill that all other skill types are based on
{
    public string DisplayName = "No Name Skill";
    public uint MPCost = 0;
    public Texture2D icon;
}

[System.Serializable]
public class Buff : Skill
{
    public float ChangeEffect = 0f;
    public float Lifetime = 1f;
    public StatEnum EffectedStat;
}

[System.Serializable]
public class Attack : Skill
{
    public float Damage = 1f;
    public float Range = 0f;
    public DamageEnum DamageType = DamageEnum.Physical;
}

[System.Serializable]
public class Summon : Skill
{
    public Transform SummonPoint;
    public GameObject prefab;
    public uint Quantity;
}