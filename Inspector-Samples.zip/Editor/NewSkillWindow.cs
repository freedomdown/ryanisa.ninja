﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class NewSkillWindow : EditorWindow
{
    public Skills2 skillObj;
    private Skill newSkill;

    public static void Init(Skills2 parentObj)
    {
        // Get existing open window or if none, make a new one:
        NewSkillWindow window = (NewSkillWindow)GetWindow(typeof(NewSkillWindow));
        window.titleContent.text = "New Skill";
        window.skillObj = parentObj; //save the Skills2 object that ran Init so we can refer to it later when saving the new skill
        window.Show();
    }

    void OnGUI()
    {
        if (newSkill == null) //if they haven't selected a type of skill yet:
        {
            GUILayout.Label("Pick the skill type:", EditorStyles.boldLabel);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Attack"))
                newSkill = new Attack();
            if (GUILayout.Button("Buff"))
                newSkill = new Buff();
            if (GUILayout.Button("Summon"))
                newSkill = new Summon();
            EditorGUILayout.EndHorizontal();

            GUILayout.FlexibleSpace(); //Fills the available space so the button below will be at the bottom.
            if (GUILayout.Button("Close"))
                this.Close();
        }
        else //skill type has been selected already:
        {
            if (newSkill.GetType() == typeof(Buff))        // BUFF SKILL
            {
                Buff temp = (Buff)newSkill;

                EditorGUILayout.BeginHorizontal();//start Icon and Name section
                temp.icon = (Texture2D)EditorGUILayout.ObjectField(temp.icon, typeof(Texture2D), false, GUILayout.Height(50f), GUILayout.Width(50f));
                EditorGUILayout.BeginVertical();
                EditorGUILayout.LabelField("Name:");
                temp.DisplayName = EditorGUILayout.TextField(temp.DisplayName);
                EditorGUILayout.EndVertical();
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start MP cost section
                EditorGUILayout.LabelField("MP Cost:", GUILayout.Width(85f));
                temp.MPCost = (uint)EditorGUILayout.IntField((int)temp.MPCost);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start change effect section
                EditorGUILayout.LabelField("Change Effect", GUILayout.Width(85f));
                temp.ChangeEffect = EditorGUILayout.FloatField(temp.ChangeEffect);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start lifetime section
                EditorGUILayout.LabelField("Lifetime", GUILayout.Width(85f));
                temp.Lifetime = EditorGUILayout.FloatField(temp.Lifetime);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start effected stat section
                EditorGUILayout.LabelField("Effected Stat", GUILayout.Width(85f));
                temp.EffectedStat = (StatEnum)EditorGUILayout.EnumPopup(temp.EffectedStat);
                EditorGUILayout.EndHorizontal();
            }
            else if (newSkill.GetType() == typeof(Attack))
            {
                Attack temp = (Attack)newSkill;

                EditorGUILayout.BeginHorizontal();//start Icon and Name section
                temp.icon = (Texture2D)EditorGUILayout.ObjectField(temp.icon, typeof(Texture2D), false, GUILayout.Height(50f), GUILayout.Width(50f));
                EditorGUILayout.BeginVertical();
                EditorGUILayout.LabelField("Name:");
                temp.DisplayName = EditorGUILayout.TextField(temp.DisplayName);
                EditorGUILayout.EndVertical();
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start MP cost section
                EditorGUILayout.LabelField("MP Cost:", GUILayout.Width(85f));
                temp.MPCost = (uint)EditorGUILayout.IntField((int)temp.MPCost);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of damage section
                EditorGUILayout.LabelField("Damage", GUILayout.Width(85f));
                temp.Damage = EditorGUILayout.FloatField(temp.Damage);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of range section
                EditorGUILayout.LabelField("Range", GUILayout.Width(85f));
                temp.Range = EditorGUILayout.FloatField(temp.Range);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of damage type section
                EditorGUILayout.LabelField("Damage Type", GUILayout.Width(85f));
                temp.DamageType = (DamageEnum)EditorGUILayout.EnumPopup(temp.DamageType);
                EditorGUILayout.EndHorizontal();
            }
            else if (newSkill.GetType() == typeof(Summon))
            {
                Summon temp = (Summon)newSkill;

                EditorGUILayout.BeginHorizontal();//start Icon and Name section
                temp.icon = (Texture2D)EditorGUILayout.ObjectField(temp.icon, typeof(Texture2D), false, GUILayout.Height(50f), GUILayout.Width(50f));
                EditorGUILayout.BeginVertical();
                EditorGUILayout.LabelField("Name:");
                temp.DisplayName = EditorGUILayout.TextField(temp.DisplayName);
                EditorGUILayout.EndVertical();
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start MP cost section
                EditorGUILayout.LabelField("MP Cost:", GUILayout.Width(85f));
                temp.MPCost = (uint)EditorGUILayout.IntField((int)temp.MPCost);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of quantity section
                EditorGUILayout.LabelField("Quantity", GUILayout.Width(85f));
                temp.Quantity = (uint)EditorGUILayout.IntField((int)temp.Quantity);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of summon point section
                EditorGUILayout.LabelField("Summon Point", GUILayout.Width(85f));
                temp.SummonPoint = (Transform)EditorGUILayout.ObjectField(temp.SummonPoint, typeof(Transform), false);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();//start of prefab section
                EditorGUILayout.LabelField("Prefab", GUILayout.Width(85f));
                temp.prefab = (GameObject)EditorGUILayout.ObjectField(temp.prefab, typeof(GameObject), false);
                EditorGUILayout.EndHorizontal();
            }

                GUILayout.FlexibleSpace();

            //Check to make sure things are correctly filled in before saving the new skill
            if (newSkill.DisplayName == "")
            {//display an error if the display name is empty
                GUI.color = Color.red;//color everything red
                EditorGUILayout.LabelField("ERROR:     !!!!NO NAME!!!");
            }

            if (GUILayout.Button("Save"))
            {
                if (newSkill.DisplayName != "")//only let them save if the display name isn't blank
                {
                    skillObj.AddNewSkill(newSkill);
                    //instead of using the skillObj to know where to add the skill,
                    //you could assume that they want to add it to the currently selected gameobject.
                    //using Selection.activeGameObject and checking to make sure it has a skills2 component
                    this.Close();
                }
            }
                
        }
        

    }
}
