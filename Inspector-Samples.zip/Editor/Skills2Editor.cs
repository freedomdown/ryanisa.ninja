﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Skills2))]
public class Skills2Editor : Editor
{

    public override void OnInspectorGUI()//Runs when a selected GameObject has the Skills2 component attached and it is minimized
    {
        Skills2 skillObj = (Skills2)target;

        DrawDefaultInspector();//draw the current and max MPs variable using the default inspector
        //not super useful in this case as there are only 2 things in it

        int total = skillObj.BuffArray.Count + skillObj.AttackArray.Count + skillObj.SummonArray.Count;
        EditorGUILayout.LabelField("Skill List:   " + total.ToString() + " total");
        if (GUILayout.Button("New Skill"))
        {
            NewSkillWindow.Init(skillObj);//pass it the Skills2 object so it knows where to add the new skill when it is done.
        }
        EditorGUILayout.Space();

        //We couldn't do this in the Skills script but it is safe to treat them all as the base class (Skill)
        //because unity won't be serializing the variables in this script.
        List<Skill> tempArray = new List<Skill>();
        tempArray.AddRange(skillObj.BuffArray.ToArray());
        tempArray.AddRange(skillObj.AttackArray.ToArray());
        tempArray.AddRange(skillObj.SummonArray.ToArray());
        //sort list before displaying them.  You could have a dropdown list of different ways to sort them
        tempArray.Sort((x, y) => (int)(x.MPCost - y.MPCost));

        foreach (Skill skill in tempArray)
        {
            EditorGUILayout.LabelField("", GUI.skin.horizontalSlider);

            EditorGUILayout.BeginHorizontal();
            skill.icon = (Texture2D)EditorGUILayout.ObjectField(skill.icon, typeof(Texture2D), false, GUILayout.Height(50f), GUILayout.Width(50f));
            EditorGUILayout.BeginVertical();
            EditorGUILayout.LabelField("Name:");
            skill.DisplayName = EditorGUILayout.DelayedTextField(skill.DisplayName);
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("MP Cost:", GUILayout.Width(85f));
            skill.MPCost = (uint)EditorGUILayout.DelayedIntField((int)skill.MPCost);
            EditorGUILayout.EndHorizontal();

            if (skill.GetType() == typeof(Buff))        // BUFF SKILL
            {
                Buff temp = (Buff)skill;
                EditorGUILayout.LabelField("Type:  BUFF");

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Change Effect", GUILayout.Width(85f));
                temp.ChangeEffect = EditorGUILayout.FloatField(temp.ChangeEffect);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Lifetime", GUILayout.Width(85f));
                temp.Lifetime = EditorGUILayout.FloatField(temp.Lifetime);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Effected Stat", GUILayout.Width(85f));
                temp.EffectedStat = (StatEnum)EditorGUILayout.EnumPopup(temp.EffectedStat);
                EditorGUILayout.EndHorizontal();

                if (GUILayout.Button("Delete"))
                {
                    skillObj.BuffArray.Remove(temp);
                }

            } else if (skill.GetType() == typeof(Attack))       //ATTACK SKILL
            {
                Attack temp = (Attack)skill;
                EditorGUILayout.LabelField("Type:  ATTACK");

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Damage", GUILayout.Width(85f));
                temp.Damage = EditorGUILayout.FloatField(temp.Damage);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Range", GUILayout.Width(85f));
                temp.Range = EditorGUILayout.FloatField(temp.Range);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Damage Type", GUILayout.Width(85f));
                temp.DamageType = (DamageEnum)EditorGUILayout.EnumPopup(temp.DamageType);
                EditorGUILayout.EndHorizontal();

                if (GUILayout.Button("Delete"))
                {
                    skillObj.AttackArray.Remove(temp);
                }

            } else if (skill.GetType() == typeof(Summon))       //SUMMON SKILL
            {
                Summon temp = (Summon)skill;
                EditorGUILayout.LabelField("Type:  SUMMON");

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Quantity", GUILayout.Width(85f));
                temp.Quantity = (uint)EditorGUILayout.IntField((int)temp.Quantity);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Summon Point", GUILayout.Width(85f));
                temp.SummonPoint = (Transform)EditorGUILayout.ObjectField(temp.SummonPoint, typeof(Transform), false);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Prefab", GUILayout.Width(85f));
                temp.prefab = (GameObject)EditorGUILayout.ObjectField(temp.prefab, typeof(GameObject), false);
                EditorGUILayout.EndHorizontal();

                if (GUILayout.Button("Delete"))
                {
                    skillObj.SummonArray.Remove(temp);
                }
            }

            EditorGUILayout.Space();
            
        }
    }
	
}
